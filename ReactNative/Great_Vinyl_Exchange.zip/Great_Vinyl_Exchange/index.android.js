import { AppRegistry } from 'react-native';
import AppRoot from './src/app/AppRoot';

AppRegistry.registerComponent('Great_Vinyl_Exchange', () => AppRoot);
